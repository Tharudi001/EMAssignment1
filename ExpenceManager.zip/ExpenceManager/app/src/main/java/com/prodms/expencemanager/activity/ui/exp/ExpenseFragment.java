package com.prodms.expencemanager.activity.ui.exp;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.activity.ui.stat.StatAdaptor;
import com.prodms.expencemanager.activity.ui.stat.StatViewModel;
import com.prodms.expencemanager.databinding.FragmentExpenseBinding;
import com.prodms.expencemanager.databinding.FragmentIncomeBinding;
import com.prodms.expencemanager.model.Category;
import com.prodms.expencemanager.model.Transaction;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ExpenseFragment extends Fragment {


    private @NonNull FragmentExpenseBinding binding;
    private PieChart pieChart;
    private FirebaseAuth mAuth;
    private DatabaseReference ref;

    private ArrayList<Transaction> trans;
    private ArrayList<StatViewModel> stats;
    private StatAdaptor adapter;

    public ExpenseFragment() {
        // Required empty public constructor
    }

    public static ExpenseFragment newInstance() {
        ExpenseFragment fragment = new ExpenseFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentExpenseBinding.inflate(inflater, container, false);
        final View root = binding.getRoot();

        pieChart = root.findViewById(R.id.piechart);

        mAuth = FirebaseAuth.getInstance();
        ref = FirebaseDatabase.getInstance().getReference().child(mAuth.getCurrentUser().getUid()).child("transaction");
        ref.keepSynced(true);
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                trans = new ArrayList<>();
                stats = new ArrayList<>();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    Transaction transaction=ds.getValue(Transaction.class);
                    trans.add(transaction);
                }
                update(root);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return root;
    }

    private void update(View root) {
        Long tot = 0l;
        Long income = 0l;
        Long exp = 0l;
        HashMap<String,StatViewModel> f = new HashMap<>();
        Collections.reverse(trans);
        if(trans!=null)
            for (Transaction t : trans) {
                if(t.getType()>0) continue;
                Category c = t.getCategory();

                if(f.containsKey(c.getName())){
                    StatViewModel svm = f.get(c.getName());
                    long a = svm.getAmount()+t.getAmount();
                    svm.setAmount(a);
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        f.replace(c.getName(),svm);
                    } else {
                        f.remove(c.getName());
                        f.put(c.getName(),svm);
                    }
                } else {
                    long a =t.getAmount();
                    StatViewModel svm = new StatViewModel();
                    svm.setCatName(c.getName());
                    svm.setAmount(a);
                    svm.setType(c.getType());
                    svm.setIcon(c.getIcon());
                    svm.setColor(c.getColor());
                    f.put(c.getName(),svm);
                }
                tot += t.getAmount()*t.getType();
                if(t.getType()>0){
                    income+=t.getAmount();
                }else {
                    exp+=t.getAmount();
                }
            }

        for (Map.Entry m :
                f.entrySet()) {
            StatViewModel svm = (StatViewModel) m.getValue();
            stats.add(svm);
            pieChart.addPieSlice(
                    new PieModel(
                            m.getKey().toString(),
                            svm.getAmount(), Color.parseColor(svm.getColor())));
        }
        pieChart.startAnimation();
        ListView favoriteListView = root.findViewById(R.id.exp_categories_list_view);
        adapter = new StatAdaptor(stats, getActivity().getApplicationContext());
        favoriteListView.setAdapter(adapter);
    }
}