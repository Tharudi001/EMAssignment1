package com.prodms.expencemanager.adaptor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.model.Category;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CategoryAdaptor extends RecyclerView.Adapter<CategoryAdaptor.CatViewHolder> {

    Context mContext;
    List<Category> mData;

    public CategoryAdaptor(Context mContext, List<Category> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public CatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(mContext).inflate(R.layout.single_cat_view,parent,false);

        return new CatViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull CatViewHolder holder, int position) {
        holder.catName.setText(mData.get(position).getName());
        Glide.with(mContext).load(getImage(mData.get(position).getIcon())).into(holder.catIcon);

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public int getImage(String imageName) {

        int drawableResourceId = mContext.getResources().getIdentifier(imageName, "drawable", mContext.getPackageName());

        return drawableResourceId;
    }

    public class CatViewHolder extends RecyclerView.ViewHolder{

        TextView catName;
        ImageView catIcon;

        public CatViewHolder(@NonNull View itemView) {
            super(itemView);

            catName = (TextView) itemView.findViewById(R.id.single_cat_name);
            catIcon = (ImageView) itemView.findViewById(R.id.single_cat_icon);


        }
    }
}
