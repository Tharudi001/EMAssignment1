package com.prodms.expencemanager.activity.ui.home;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.activity.ui.income.IncomeFragment;
import com.prodms.expencemanager.adaptor.TransactionAdapter;
import com.prodms.expencemanager.databinding.FragmentHomeBinding;
import com.prodms.expencemanager.model.Transaction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.preference.PreferenceManager;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private FirebaseAuth mAuth;
    private DatabaseReference ref;
    private ArrayList<Transaction> trans;
    private TransactionAdapter adapter;
    private ProgressBar goalProgress;
    private TextView goalText;
    private int goalTarget;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        final View root = binding.getRoot();
        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(getContext());

        goalProgress = root.findViewById(R.id.goal_progress);
        goalText = root.findViewById(R.id.goal_text);
        try {
            goalTarget = Integer.parseInt(sharedPreferences.getString("target", "30000"));
        }catch (NumberFormatException e){
            goalTarget = 30000;
        }

        mAuth = FirebaseAuth.getInstance();
        ref = FirebaseDatabase.getInstance().getReference().child(mAuth.getCurrentUser().getUid()).child("transaction");
        ref.keepSynced(true);
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //ArrayList<Category> categories;
                trans = new ArrayList<>();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    Transaction transaction=ds.getValue(Transaction.class);
                    trans.add(transaction);
                }
                update(root);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        root.findViewById(R.id.btn_exp).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Fragment fragment = IncomeFragment.newInstance();
//
//                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//
//                transaction.replace(R.id.home, fragment).commit();
//            }
//        });

//        final TextView textView = binding.textHome;
//        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }

    private void update(View view) {
        Long tot = 0l;
        Long income = 0l;
        Long exp = 0l;
        if(trans!=null)
        for (Transaction t :
                trans) {
            tot += t.getAmount()*t.getType();
            if(t.getType()>0){
                income+=t.getAmount();
            }else {
                exp+=t.getAmount();
            }
        } else {
            trans = new ArrayList<>();
        }
        TextView totText = (TextView) view.findViewById(R.id.home_tot);
        TextView inText = (TextView) view.findViewById(R.id.home_income);
        TextView expText = (TextView) view.findViewById(R.id.home_exp);

        int gp = Math.round((goalTarget - exp) * 100 / goalTarget);

        goalProgress.setProgress(gp);
        goalText.setText(exp + "/" + goalTarget + "("+gp+"%)");

        totText.setText(tot + " LKR");
        inText.setText(income + " LKR");
        expText.setText(exp + " LKR");

        Collections.reverse(trans);

        ListView favoriteListView = view.findViewById(R.id.favourite_categories_list_view);
        adapter = new TransactionAdapter(trans, getActivity().getApplicationContext());
        favoriteListView.setAdapter(adapter);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}