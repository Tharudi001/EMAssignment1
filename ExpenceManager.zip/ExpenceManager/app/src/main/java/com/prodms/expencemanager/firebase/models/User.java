package com.prodms.expencemanager.firebase.models;

import java.util.HashMap;

public class User {
//    public Currency currency = new Currency("$", true, true);
//    public UserSettings userSettings = new UserSettings();
//    public Wallet wallet = new Wallet();
//    public Map<String, WalletEntryCategory> customCategories = new HashMap<>();

    public User() {

    }
}
