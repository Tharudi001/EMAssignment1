package com.prodms.expencemanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.collection.ArraySet;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.adaptor.EntryCatAdapter;
import com.prodms.expencemanager.adaptor.EntryCategoriesAdapter;
import com.prodms.expencemanager.adaptor.EntryTypesAdapter;
import com.prodms.expencemanager.helper.CategoriesHelper;
import com.prodms.expencemanager.helper.EntryType;
import com.prodms.expencemanager.model.Category;
import com.prodms.expencemanager.model.Transaction;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class AddEntryActivity extends AppCompatActivity {

    private Spinner selectCategorySpinner;
    private TextInputEditText selectNameEditText;
    private Calendar chosenDate;
    private TextInputEditText selectAmountEditText;
    private TextView chooseDayTextView;
    private TextView chooseTimeTextView;
    private Spinner selectTypeSpinner;
    //private User user;
    private TextInputLayout selectAmountInputLayout;
    private TextInputLayout selectNameInputLayout;
    private Button addEntryButton;

    FirebaseAuth mAuth;
    DatabaseReference ref;
    private ArrayList<Category> categories;
    private List<Category> selectedList;
    private int type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);
        getSupportActionBar().setTitle("Add Transaction");

        type = 0;
        mAuth = FirebaseAuth.getInstance();
        ref = FirebaseDatabase.getInstance().getReference().child(mAuth.getCurrentUser().getUid()).child("transaction");
        ref.keepSynced(true);
        selectCategorySpinner = findViewById(R.id.select_category_spinner);
        selectNameEditText = findViewById(R.id.select_name_edittext);
        selectNameInputLayout = findViewById(R.id.select_name_input_layout);
        selectTypeSpinner = findViewById(R.id.select_type_spinner);
        addEntryButton = findViewById(R.id.add_entry_button);
        chooseTimeTextView = findViewById(R.id.choose_time_textview);
        chooseDayTextView = findViewById(R.id.choose_day_textview);
        selectAmountEditText = findViewById(R.id.select_amount_edittext);
        selectAmountInputLayout = findViewById(R.id.select_amount_inputlayout);
        chosenDate = Calendar.getInstance();

        EntryTypesAdapter typeAdapter = new EntryTypesAdapter(this,
                R.layout.new_entry_type_spinner_row, Arrays.asList(
                new EntryType("Expense", Color.parseColor("#ef5350"),
                        R.drawable.ic_exp_round),
                new EntryType("Income", Color.parseColor("#66bb6a"),
                        R.drawable.ic_income_round)));

        selectTypeSpinner.setAdapter(typeAdapter);

        DatabaseReference db = FirebaseDatabase.getInstance().getReference().child("category");
        db.keepSynced(true);
        db.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //ArrayList<Category> categories;
                categories = new ArrayList<>();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    Category category=ds.getValue(Category.class);
                    categories.add(category);
                }
                updateCatSpinner();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        selectTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                type = position;
                updateCatSpinner();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        updateDate();

        chooseDayTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDate();
            }
        });
        chooseTimeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickTime();
            }
        });

        addEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int type = (selectTypeSpinner.getSelectedItemPosition() * 2) - 1;
                Category cat = selectedList.get(selectCategorySpinner.getSelectedItemPosition());
                long amount = Long.parseLong(selectAmountEditText.getText().toString());
                String name = selectNameEditText.getText().toString();
                addToWallet(type,amount, chosenDate.getTime(), cat, name );
            }
        });

    }

    private void updateCatSpinner(){
        if(categories == null) return;
        int t = type*2-1;
        List<Category> nList = new ArrayList<>();
        for(Category c: categories){
            if(c.getType()==t){
                nList.add(c);
            }
        }
        selectedList = nList;
        EntryCategoriesAdapter catAdapter = new EntryCategoriesAdapter(AddEntryActivity.this,
                R.layout.new_entry_type_spinner_row, nList);
        selectCategorySpinner.setAdapter(catAdapter);
    }
    private void updateDate() {
        SimpleDateFormat dataFormatter = new SimpleDateFormat("yyyy-MM-dd");
        chooseDayTextView.setText(dataFormatter.format(chosenDate.getTime()));

        SimpleDateFormat dataFormatter2 = new SimpleDateFormat("HH:mm");
        chooseTimeTextView.setText(dataFormatter2.format(chosenDate.getTime()));
    }

    private void pickTime() {
        new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                chosenDate.set(Calendar.HOUR_OF_DAY, hourOfDay);
                chosenDate.set(Calendar.MINUTE, minute);
                updateDate();

            }
        }, chosenDate.get(Calendar.HOUR_OF_DAY), chosenDate.get(Calendar.MINUTE), true).show();
    }

    private void pickDate() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        chosenDate.set(year, monthOfYear, dayOfMonth);
                        updateDate();

                    }
                }, year, month, day).show();
    }

    private void addToWallet(int type, long balanceDifference, Date entryDate, Category entryCategory, String entryName) {

        addEntryButton.setEnabled(false);
        Transaction transaction = new Transaction(type, entryCategory, entryName, entryDate.getTime(), balanceDifference);
        String key = ref.push().getKey();
        transaction.setKey(key);
        ref.child(key).setValue(transaction).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(getApplicationContext(),"Transaction Added Successfully", Toast.LENGTH_LONG);
                } else {
                    Toast.makeText(AddEntryActivity.this,"Transaction Adding Error", Toast.LENGTH_LONG);
                }
                addEntryButton.setEnabled(true);
            }
        });
        super.onBackPressed();
//        user.wallet.sum += balanceDifference;
//        UserProfileViewModelFactory.saveModel(getUid(), user);
//        finishWithAnimation();
    }

}