package com.prodms.expencemanager.activity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.databinding.ActivityDashBinding;
import com.prodms.expencemanager.model.Category;

import androidx.annotation.NonNull;
import androidx.core.app.NavUtils;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;


public class DashActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityDashBinding binding;
    private FirebaseAuth mAuth;
    private ImageView userImg;
    private TextView userName,userEmail;

    private FirebaseUser user;

    private DatabaseReference catRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();

        setSupportActionBar(binding.appBarDash.toolbar);
        binding.appBarDash.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//
                ActivityOptions options =
                        ActivityOptions.makeSceneTransitionAnimation(DashActivity.this, binding.appBarDash.fab, binding.appBarDash.fab.getTransitionName());
                startActivity(new Intent(DashActivity.this, AddEntryActivity.class), options.toBundle());
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;


        user = mAuth.getCurrentUser();

        View header = navigationView.getHeaderView(0);

        userImg = (ImageView) header.findViewById(R.id.nav_user_img);
        userName = (TextView) header.findViewById(R.id.nav_username);
        userEmail = (TextView) header.findViewById(R.id.nav_email);

        Glide.with(this).load(user.getPhotoUrl()).into(userImg);

        //userImg.setImageBitmap(bmp);
        userName.setText(user.getDisplayName());
        userEmail.setText(user.getEmail());

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_category, R.id.nav_income, R.id.nav_exp, R.id.nav_stat)
                .setOpenableLayout(drawer)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_dash);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dash, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_dash);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            //Toast.makeText(this,"Settings Clicked", Toast.LENGTH_LONG).show();
            startActivity(new Intent(DashActivity.this, SettingsActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}