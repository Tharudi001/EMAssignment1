package com.prodms.expencemanager.helper;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prodms.expencemanager.model.Category;

import java.util.ArrayList;

import androidx.annotation.NonNull;

public class CategoriesHelper {
    private DatabaseReference db;
    ArrayList<Category> categoryList;
    Boolean saved=null;

    public CategoriesHelper() {
        db = FirebaseDatabase.getInstance("https://expensemanager-ec63e-default-rtdb.asia-southeast1.firebasedatabase.app").getReference();

    }

    public  Boolean save(Category category)
    {
        if(category==null)
        {
            saved=false;
        }else
        {
            try
            {
                db.push().setValue(category);
                saved=true;
            }catch (DatabaseException e)
            {
                e.printStackTrace();
                saved=false;
            }
        }

        return saved;
    }
    public ArrayList<Category> retrieve()
    {
        final ArrayList<Category> categories=new ArrayList<>();

        db.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return categories;
    }

    private void fetchData(DataSnapshot snapshot,ArrayList<Category> categories)
    {
        categories.clear();
        for (DataSnapshot ds:snapshot.getChildren())
        {
            Category category=ds.getValue(Category.class);
            categories.add(category);
        }

    }
}
