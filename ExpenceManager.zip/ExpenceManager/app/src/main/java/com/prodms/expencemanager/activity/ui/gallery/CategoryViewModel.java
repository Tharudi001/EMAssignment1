package com.prodms.expencemanager.activity.ui.gallery;

import com.prodms.expencemanager.model.Category;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CategoryViewModel extends ViewModel {

    private LiveData<List<Category>> catList;

    public CategoryViewModel() {
        catList = new LiveData<List<Category>>() {};
        //catList.setValue("This is gallery fragment");
    }

}