package com.prodms.expencemanager.activity.ui.stat;

public class StatViewModel {
    private String catName;
    private String color;
    private String icon;
    private long amount;
    private int type;

    public StatViewModel(String catName, String color, String icon, long amount, int type) {
        this.catName = catName;
        this.color = color;
        this.icon = icon;
        this.amount = amount;
        this.type = type;
    }

    public StatViewModel() {
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
