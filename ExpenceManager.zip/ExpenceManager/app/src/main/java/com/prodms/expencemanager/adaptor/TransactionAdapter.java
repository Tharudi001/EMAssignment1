package com.prodms.expencemanager.adaptor;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.prodms.expencemanager.R;
import com.prodms.expencemanager.model.Category;
import com.prodms.expencemanager.model.Transaction;

import java.util.ArrayList;

import androidx.core.content.ContextCompat;

public class TransactionAdapter extends ArrayAdapter<Transaction> implements View.OnClickListener{
    private ArrayList<Transaction> dataSet;
    Context context;

    public TransactionAdapter(ArrayList<Transaction> data, Context context) {
        super(context, R.layout.single_transaction_view, data);
        this.dataSet = data;
        this.context = context;

    }

    @Override
    public void onClick(View v) {

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null)
            listItem = LayoutInflater.from(context).inflate(R.layout.single_transaction_view, parent, false);

        Transaction dataModel = getItem(position);
        Category category = dataModel.getCategory();

        TextView cat = listItem.findViewById(R.id.item_category);
        TextView name = listItem.findViewById(R.id.item_name);
        TextView sumTextView = listItem.findViewById(R.id.item_sum);
        ImageView iconImageView = listItem.findViewById(R.id.icon_imageview);

        //iconImageView.setImageResource(category.getIcon());
        Glide.with(context).load(getImage(category.getIcon())).into(iconImageView);
        iconImageView.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context,R.color.browser_actions_bg_grey)));

        name.setText(dataModel.getName());
        cat.setText(category.getName());
        sumTextView.setText(dataModel.getAmount() + " LKR");
        if (dataModel.getType() < 0)
            sumTextView.setTextColor(ContextCompat.getColor(context, R.color.gauge_expense));
        else
            sumTextView.setTextColor(ContextCompat.getColor(context, R.color.gauge_income));

        listItem.setClickable(false);
        listItem.setOnClickListener(null);
        return listItem;
    }
    public int getImage(String imageName) {
        int drawableResourceId = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        return drawableResourceId;
    }
}
