package com.prodms.expencemanager.model;

public class Transaction {
    public String key;
    public int type;
    public Category category;
    public String name;
    public long timestamp;
    public long amount;

    public Transaction() {

    }

    public Transaction(int type,Category category, String name, long timestamp, long amount) {
        this.type = type;
        this.category = category;
        this.name = name;
        this.timestamp = -timestamp;
        this.amount = amount;
    }

    public void setKey(String key) {
        this.key=key;
    }

    public String getKey() {
        return key;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
