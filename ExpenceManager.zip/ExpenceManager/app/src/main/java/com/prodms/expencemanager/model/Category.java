package com.prodms.expencemanager.model;

import com.google.firebase.database.ServerValue;

public class Category {

    private Long key;
    private String name;
    private String icon;
    private String color;
    private int type;
    private Object timeStamp;

    public Category(String name, String icon, int type, String color) {
        this.name = name;
        this.icon = icon;
        this.color = color;
        this.type = type;
        this.timeStamp = ServerValue.TIMESTAMP;
    }

    public Category() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Object getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Object timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Long getKey() {
        return key;
    }

    public void setKey(Long key) {
        this.key = key;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
